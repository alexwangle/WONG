module.exports = class extends think.Model {

};
