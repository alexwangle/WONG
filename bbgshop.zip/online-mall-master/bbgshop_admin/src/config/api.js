const CorporateName = 'dw'
const UploadAddress = ''
export default {
  CorporateName,
  UploadAddress
}
